package com.inf4705.tp1;

public class InvalidMatrixFormatException extends Throwable {
}
