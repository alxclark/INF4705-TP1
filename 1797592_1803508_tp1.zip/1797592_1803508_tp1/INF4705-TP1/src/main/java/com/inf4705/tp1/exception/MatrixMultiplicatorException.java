package com.inf4705.tp1.exception;

public class MatrixMultiplicatorException extends RuntimeException {
	public MatrixMultiplicatorException(String message){
		super(message);
	}
}
