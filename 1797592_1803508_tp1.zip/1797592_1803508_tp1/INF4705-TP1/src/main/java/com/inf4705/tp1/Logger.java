package com.inf4705.tp1;

public class Logger {
	public static void logLine(String text) {
		System.out.println(text);
	}

	public static void log(String text){
		System.out.print(text);
	}

	public static void blankLine() {
		System.out.println();
	}
}
